<?php 
session_start();
session_destroy();
	header('location:user1.php');
?>